﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace QxLoad
{
    static class Program
    {
        private static Mutex fdsfre;

        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            fdsfre = new Mutex(true, "zdr34bf42", out bool created);
            if (!created)
            {
                Environment.Exit(0);
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new xqgfryeq());
        }
    }
}
